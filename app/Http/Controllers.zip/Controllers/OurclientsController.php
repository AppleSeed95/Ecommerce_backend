<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OurclientsController extends Controller
{
    //
}
